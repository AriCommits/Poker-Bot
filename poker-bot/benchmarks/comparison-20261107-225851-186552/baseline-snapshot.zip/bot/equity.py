"""Monte Carlo equity estimates for Short Deck 5-Card PLO."""

from __future__ import annotations

import random
from typing import Sequence

from evaluator import NUM_CARDS, omaha_score
from game import Street

from bot.config import BotConfig, DEFAULT_CONFIG


def _remaining_cards(dead: Sequence[int]) -> list[int]:
    dead_set = set(dead)
    return [c for c in range(NUM_CARDS) if c not in dead_set]


def estimate_equity(
    hole: Sequence[int],
    board: Sequence[int],
    street: Street,
    rng: random.Random,
    config: BotConfig = DEFAULT_CONFIG,
    opp_hole: Sequence[int] | None = None,
) -> float:
    """Estimate P(win) + 0.5 * P(tie) vs a random opponent hand (or known hole).

    Uses a small sample count tuned for the tournament time bank. On the river
    with a full board, opponent hands are sampled without redealing the board.
    """
    board = list(board)
    hole = list(hole)
    n_board = len(board)

    if street == Street.PREFLOP or n_board == 0:
        # Caller should prefer the preflop lookup table; this path is a fallback.
        samples = min(12, config.max_samples_per_decision)
    elif street == Street.FLOP or n_board == 3:
        samples = config.samples.flop
    elif street == Street.TURN or n_board == 4:
        samples = config.samples.turn
    else:
        samples = config.samples.river

    samples = max(1, min(samples, config.max_samples_per_decision))
    need_board = 5 - n_board

    wins = 0.0
    for _ in range(samples):
        dead = list(hole) + board
        if opp_hole is not None:
            dead.extend(opp_hole)
        rem = _remaining_cards(dead)
        rng.shuffle(rem)

        if opp_hole is None:
            if len(rem) < 5 + need_board:
                continue
            opp = rem[:5]
            fill = rem[5:5 + need_board]
        else:
            opp = list(opp_hole)
            if len(rem) < need_board:
                continue
            fill = rem[:need_board]

        full_board = board + fill
        hero = omaha_score(hole, full_board)
        villain = omaha_score(opp, full_board)
        if hero > villain:
            wins += 1.0
        elif hero == villain:
            wins += 0.5

    return wins / samples


def pot_odds(to_call: int, pot: int) -> float:
    """Fraction of the final pot you must win to break even on a call."""
    if to_call <= 0:
        return 0.0
    return to_call / (pot + to_call)


def required_equity(to_call: int, pot: int, edge: float = 0.0) -> float:
    """Pot odds plus an optional edge cushion."""
    return min(0.95, pot_odds(to_call, pot) * (1.0 + edge))
