# Poker Bot — Short Deck 5-Card Pot-Limit Omaha

Heads-up Short Deck (36-card) 5-Card Pot-Limit Omaha bot for the TAMU Datathon Poker Bot Challenge.

Built on the official [heads-up-bundle](https://github.com/tamu-datathon-org/heads-up-bundle) starter.

## Strategy overview

1. **Preflop** — cheap feature extraction → dictionary lookup (`data/preflop_equity.json`).
2. **Postflop** — light Monte Carlo equity vs a random opponent hand (sample counts in config).
3. **Decisions** — compare equity to pot odds, then sample from **action-frequency dictionaries** by strength bucket.
4. **All-in spice** — when equity is high, a configurable random chance forces a pot shove.

All tunable percentages live in one place: `bot/config.py` (`BotConfig` dataclass).

## Layout

| Path | Role |
|------|------|
| `agent.py` | Tournament entrypoint (edit strategy hooks only) |
| `bot/config.py` | **`BotConfig` dataclass** — thresholds, mixes, all-in rates |
| `bot/features.py` | Preflop hole-card features |
| `bot/tables.py` | Probability dictionary loaders / lookups |
| `bot/equity.py` | Monte Carlo equity + pot odds |
| `bot/policy.py` | Action selection |
| `data/preflop_equity.json` | Precomputed feature → equity table |
| `game.py` / `evaluator.py` | Official rules + hand evaluator (don't rely on local edits in tournament) |

## Quick start

```bash
cd poker-bot
pip install -r requirements.txt

# rebuild preflop lookup (optional)
python3 scripts/build_preflop_table.py --hands 4000

# unit tests for the policy
python3 -m pytest -q tests/test_policy.py test_agent.py

# local match (3 terminals)
python3 agent.py
python3 baseline-bots/baseline_random.py
python3 judge_engine.py --deals 100 --seed 7
```

## Knobs to tweak first

In `bot/config.py`:

- `mixes` — fold/call/raise frequencies per equity bucket
- `all_in_equity_threshold` / `all_in_probability` — random pot shoves
- `bluff_frequency` — free-bet bluffs
- `call_edge` / `raise_edge` — pot-odds tightness
- `samples` — MC count per street (keep low; time bank is 8s / 1000 hands)

## Submission note

The tournament expects a **public** repo whose root contains `agent.py`. This project currently lives under the `hackathons` monorepo as `poker-bot/`. For official submission, publish this folder as its own public GitHub repository (or copy it out) and submit that URL + commit SHA.
