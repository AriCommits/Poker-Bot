"""Probability dictionaries for fast equity / action lookups."""

from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Mapping

from bot.config import BotConfig, DEFAULT_CONFIG
from bot.features import HoleFeatures, extract_features, feature_key

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
PREFLOP_EQUITY_PATH = DATA_DIR / "preflop_equity.json"

# Fallback coarse equity by feature score bands when JSON is missing a key.
# These are approximate heads-up equities vs a random 5-card hand in short-deck PLO5.
SCORE_BAND_EQUITY: dict[str, float] = {
    "0-19": 0.32,
    "20-29": 0.38,
    "30-39": 0.44,
    "40-49": 0.50,
    "50-59": 0.55,
    "60-69": 0.59,
    "70-79": 0.62,
    "80+": 0.66,
}


def _score_band(score: int) -> str:
    if score < 20:
        return "0-19"
    if score < 30:
        return "20-29"
    if score < 40:
        return "30-39"
    if score < 50:
        return "40-49"
    if score < 60:
        return "50-59"
    if score < 70:
        return "60-69"
    if score < 80:
        return "70-79"
    return "80+"


@lru_cache(maxsize=1)
def load_preflop_equity_table() -> dict[str, float]:
    """Load situation → equity dictionary from JSON (empty dict if absent)."""
    if not PREFLOP_EQUITY_PATH.exists():
        return {}
    with PREFLOP_EQUITY_PATH.open() as f:
        raw = json.load(f)
    return {str(k): float(v) for k, v in raw.items()}


def lookup_preflop_equity(
    hole_cards: list[int] | tuple[int, ...],
    config: BotConfig = DEFAULT_CONFIG,
    table: Mapping[str, float] | None = None,
) -> float:
    """Fast preflop equity estimate via feature-key dictionary lookup."""
    feat = extract_features(hole_cards)
    return lookup_preflop_equity_from_features(feat, config, table)


def lookup_preflop_equity_from_features(
    feat: HoleFeatures,
    config: BotConfig = DEFAULT_CONFIG,
    table: Mapping[str, float] | None = None,
) -> float:
    """Resolve equity from feature key, then score-band fallback."""
    tbl = table if table is not None else load_preflop_equity_table()
    key = feature_key(feat)
    if key in tbl:
        equity = tbl[key]
    else:
        equity = SCORE_BAND_EQUITY[_score_band(feat.score)]
        # Light adjustment from raw score within the band.
        equity += (feat.score % 10) * 0.002

    return max(config.preflop_equity_floor, min(config.preflop_equity_ceiling, equity))


def action_frequency_dict(config: BotConfig) -> dict[str, dict[str, float]]:
    """Expose bucket → action probability dictionaries for inspection / tooling."""
    return {
        name: {
            "fold": mix.fold,
            "check_call": mix.check_call,
            "raise_half": mix.raise_half,
            "raise_pot": mix.raise_pot,
        }
        for name, mix in config.mixes.items()
    }
